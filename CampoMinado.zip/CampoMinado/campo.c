#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"campo.h"
#define tam 20

int posBombas[tam], campo[10][10];

int verificaBomba(int comparado)
{
    int z;
    for(z=0; z<tam; z++)
    {
        if(posBombas[z] == comparado)
        {
            return 1;
        }
    }
    return 0;
}

void imprime_inicio() //ESSA FUN��O SERVE PRA IMPRIMIR O ESTADO INICIAL DO CAMPO MINADO
{
    int i, j, z=0;
    system("clear");
    for(i=0; i<10; i++)
    {
        for(j=0; j<10; j++)
        {
            campo[i][j] = z;
            z++;
            if(z<10)
            {
                printf("|  %d ", campo[i][j]);
            }
            else
                printf("| %d ", campo[i][j]);
        }
        printf("\n");
    }

}


void gera_bombas()
{
    srand(time(NULL));
    int aux,contador;
    for(contador=0; contador<tam; contador++) //gera aleatoriamente as posi��es onde vamos ter as bombas
    {
        aux = rand()%100;
        while(verificaBomba(aux))
        {
            aux = rand()%100;
        }
        posBombas[contador] = aux;
    }
}

void atualiza_matriz()  //ESSA FUN��O SERVE PRA ATUALIZAR A MATRIZ DEPOIS DE VERIFICAR A VIZINHAN�A
{
    int i, j;
    system("clear");
    for(i=0; i<10; i++)
    {
        for(j=0; j<10; j++)
        {
            if(i=0)
            {
                printf("|  %d ", campo[i][j]);
            }
            else
                printf("| %d ", campo[i][j]);
        }
        printf("\n");
    }

}

void verifica_vizinhanca() //FUN��O PRA VERIFICAR A VIZINHAN�A
{
    int i, j, z, auxi, auxj, countbomba[100], k=0, escolhido;//O COUNT BOMBA � UM VETOR PARA CADA POSI��O QUE FOR CONTER UM NUMERO QUE REPRESENTA BOMBAS PROXIMAS

    while(1)
    {
        countbomba[k] = 0;
        printf("\nEscolha a posicao que deseja abrir:  ");
        scanf("%d\n",&escolhido);

        for(i=0; i<10; i++)
        {
            for(j=0; j<10; j++)
            {
                if(campo[i][j] = escolhido)
                {
                    auxi = i;  //AQUI ESTAMOS ARMAZENANDO A POSI��O SELECIONADA
                    auxj = j;
                }

            }

        }

        if(verificaBomba(escolhido)) //ESSA PARTE ANALISA SE O USARIO ACERTOU A BOMBA, E LOGO EM SEGUIDA MOSTRA TODAS AS POSI��ES DAS OUTRAS BOMBAS
        {
            for(i=0; i<10; i++)
            {
                for(j=0; j<10; j++)
                {
                    for(z=0; z<tam; z++)
                    {
                        if(campo[i][j] == posBombas[z])
                        {
                            campo[i][j] = 1;
                        }
                    }

                }

            }
            atualiza_matriz();
            printf("VOC� PERDEU!");
            exit(0);
        }

        if(!verificaBomba(escolhido))
        {
            //VERIFICANDO AS EXCE��ES DAS 4 PONTAS DA MATRIZ
            if(escolhido==0 || escolhido==9 || escolhido == 90 || escolhido == 99)
            {
                if(escolhido==0)
                {
                    if(verificaBomba(matriz[auxi][auxj++]))
                    {
                        countbomba[k]++;

                    }
                    if(verificaBomba(matriz[auxi++][auxj]))
                    {
                        countbomba[k]++;

                    }
                    if(verificaBomba(matriz[auxi++][auxj++]))
                    {
                        countbomba[k]++;

                    }

                }
                if(escolhido==9)
                {
                    if(verificaBomba(matriz[auxi][auxj--]))
                    {
                        countbomba[k]++;
                        k++;
                    }
                    if(verificaBomba(matriz[auxi++][auxj--]))
                    {
                        countbomba[k]++;
                        k++;
                    }
                    if(verificaBomba(matriz[auxi++][auxj]))
                    {
                        countbomba[k]++;
                        k++;
                    }


                }

                if(escolhido==90)
                {
                    if(verificaBomba(matriz[auxi--][auxj]))
                    {
                        countbomba[k]++;
                        k++;
                    }
                    if(verificaBomba(matriz[auxi--][auxj++]))
                    {
                        countbomba[k]++;
                        k++;
                    }
                    if(verificaBomba(matriz[auxi][auxj++]))
                    {
                        countbomba[k]++;
                        k++;
                    }


                }

                if(escolhido==99)
                {
                    if(verificaBomba(matriz[auxi--][auxj]))
                    {
                        countbomba[k]++;
                        k++;
                    }
                    if(verificaBomba(matriz[auxi--][auxj--]))
                    {
                        countbomba[k]++;
                        k++;
                    }
                    if(verificaBomba(matriz[auxi][auxj--]))
                    {
                        countbomba[k]++;
                        k++;
                    }


                }


            }

            //VERIFICANDO AS EXCE��ES DAS BEIRADAS


            //VERIFICANDO AS POSI��ES REGULARES
            else
            {
                for(i = auxi-1; i < auxi +1; i++)
                {
                    for (j = auxj-1; j < auxj +1; j++)
                    {
                        if(verificaBomba(campo[i][j]))
                        {
                            countbomba[k]++; //INCREMENTANDO O TOTAL DE BOMBAS NA DETERMINADA POSI��O DO VETOR
                        }
                    }
                }
                k++;
            }

        }
    }
}
