#include <stdio.h>
#include <stdlib.h>

int campo[10][10];

int main()
    {
        int tam,escolha;
        printf("########## BOAS VINDAS AO CAMPO MINADO ##########\n");

    imprime_inicio();


    return 1;
}

